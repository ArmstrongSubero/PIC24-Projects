/*******************************************************************************
 * File: Main.c
 * Author: Armstrong Subero
 * PIC: 24FJ128GB204 @ 32 MHz, 3.3v
 * Program: 17_FreeRTOS_Queue
 * Compiler: XC16 (Pro) (v1.31, MPLAX X v3.55)
 * Program Version: 1.0
 *                
 * Program Description: This Program Allows PIC24FJ128GB204 to use FreeRTOS
 *                      and utilizes Queues. A total of three tasks, two
 *                      instances of one and one instance of another are sent
 *                      to the Queue. Another task reads the queue and prints 
 *                      the result to the OLED. 
 * 
 * Hardware Description: 
 *                     An SSD1306 is connected to the microcontroller as per 
 *                     MCC generated code. 
 *                     SCL -> A0
 *                     SDA -> A1
 *                     4.7 k pullup resistors are used on the communication 
 *                     lines. An LED is connected to RA7 and another to RB9
 * 
 * Created May 10th, 2017, 6:51 PM
 * 
 *
 * License:
 * 
 * "Copyright (c) 2017 Armstrong Subero ("AUTHORS")"
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the authors appear in all copies of this software.
 *
 * IN NO EVENT SHALL THE "AUTHORS" BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE "AUTHORS"
 * HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE "AUTHORS" SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE "AUTHORS" HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 * Please maintain this header in its entirety when copying/modifying
 * these files.
 * 
 ******************************************************************************/

/*******************************************************************************
 * Includes and defines
 ******************************************************************************/
/* Standard includes. */
#include "PIC24_PIC33_I2C.h"
#include "PIC24FJ128GB204_STD.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <math.h>
#include <ctype.h>
#include <stdbool.h>
#include "SSD1306_OLED.h"

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/*******************************************************************************
 * Function Prototypes
 ******************************************************************************/
void prvSetupHardware();                              // Setup Hardware

static void vSenderTask   (void *pvParameters);       // First  Send Task
static void vSenderTask2  (void *pvParameters);       // Second Send Task
static void vReceiveTask  (void *pvParameters);       // Receive Task

void vApplicationIdleHook( void );                    // IDLE Hook
void vOLEDString(uint8_t x, uint8_t y, char* String); // Print string to OLED
void vOLEDInteger(uint8_t x, uint8_t y, uint32_t z);  // Print integer on OLED


QueueHandle_t xQueue;                                 // Handle to queue

/*******************************************************************************
 * Global Variables
 ******************************************************************************/
#define MAX_TASKS_STACK_SIZE             ( configMINIMAL_STACK_SIZE * 4 )
#define MED_TASKS_STACK_SIZE			 ( configMINIMAL_STACK_SIZE * 2 )
#define MIN_TASKS_STACK_SIZE             ( configMINIMAL_STACK_SIZE )

#define SUPER_PRIORITY  4
#define HIGH_PRIORITY   3
#define MED_PRIORITY    2
#define LOW_PRIORITY    1
#define IDLE_PRIORITY   0

/*******************************************************************************
 * Function:        int main(void)
 *
 * PreCondition:    STD FreeRTOS requirements
 *
 * Input:           None
 *
 * Output:          None
 *
 * Overview:        Program Entry Point
 * 
 * Usage:           None
 *
 * Note:            None
 ******************************************************************************/
int main(void)
{
    // Setup hardware 
    prvSetupHardware();
    
    xQueue = xQueueCreate( 5, sizeof( int32_t));
    
    if (xQueue != NULL)
    {
        /* ---  APPLICATION TASKS  --- */
        // Two instances of sender one task are send together with one instance 
        // sender two, the sender tasks must be higher priority
    
           /*|-----------------------------------------------------------------------------------------|
                 TaskPtr        TaskName      StackDepth(words)      Parameters     Priority     Handle
           * |-----------------------------------------------------------------------------------------|*/
          xTaskCreate(vSenderTask,  "Sender1.0",  MIN_TASKS_STACK_SIZE,   (void*)100,  HIGH_PRIORITY, NULL);
          xTaskCreate(vSenderTask,  "Sender1.1",  MIN_TASKS_STACK_SIZE,   (void*)200,  HIGH_PRIORITY, NULL);
    
          xTaskCreate(vSenderTask2, "Sender2.0",  MIN_TASKS_STACK_SIZE,   (void*)300,  HIGH_PRIORITY, NULL); 
          xTaskCreate(vReceiveTask, "Receiver",   MED_TASKS_STACK_SIZE,    NULL,      SUPER_PRIORITY, NULL);
     
          // Start scheduler
          vTaskStartScheduler();
    }
    
    else
    {
        // Queue not created
        LATAbits.LATA7 = 1;
    }
    
    /* ---   NOT REACHABLE --- */
    // Execution only reaches here due to insufficient heap
    for(;;);
    
    return 0;
}

/*******************************************************************************
 * Function:        void vSenderTask(void *pvParameters)
 *
 * PreCondition:    STD FreeRTOS requirements
 *
 * Input:           None
 *
 * Output:          None
 *
 * Overview:        Sends a value to the queue
 * 
 * Usage:           None
 *
 * Note:            None
 ******************************************************************************/
static void vSenderTask(void *pvParameters)
{
    int32_t lValueToSend;
    BaseType_t xStatus;
    
    // Two instances of task are created holds values of types int32_t
    lValueToSend =  ( int32_t ) pvParameters;
    
    // implement in infinite loop
    for(;;)
    {
       // Send value to queue, first param is queue to send to
       // Second param is address of data to be sent
       // Third block time, time task is kept in blocked state
        xStatus = xQueueSendToBack( xQueue, &lValueToSend, 0);
        
        if (xStatus != pdPASS)
        {
            LATBbits.LATB9 = 1;
        }
        
        else{
            LATBbits.LATB9 = 0;
        }
    }
    
}

/*******************************************************************************
 * Function:        void vSenderTask2(void *pvParameters)
 *
 * PreCondition:    STD FreeRTOS requirements
 *
 * Input:           *pvParameters
 *
 * Output:          None
 *
 * Overview:        Sends a message to the Queue
 * 
 * Usage:           None
 *
 * Note:            None
 ******************************************************************************/
static void vSenderTask2(void *pvParameters)
{
    int32_t lValueToSend;
    BaseType_t xStatus;
    
    // Two instances of task are created holds values of types int32_t
    lValueToSend = ( int32_t ) pvParameters;
    
    // implement in infinite loop
    for(;;)
    {
       // Send value to queue, first param is queue to send to
       // Second param is address of data to be sent
       // Third block time, time task is kept in blocked state
        xStatus = xQueueSendToBack( xQueue, &lValueToSend, 0);
        
        if (xStatus != pdPASS)
        {
            LATBbits.LATB9 = 1;
        }
        
        else{
            LATBbits.LATB9 = 0;
        }
    }
    
}


/*******************************************************************************
 * Function:        void vReceiveTask(void *pvParameters)
 *
 * PreCondition:    STD FreeRTOS requirements
 *
 * Input:           None
 *
 * Output:          None
 *
 * Overview:        Receives message from Queue and prints it on OLED
 * 
 * Usage:           None
 *
 * Note:            None
 ******************************************************************************/
void vReceiveTask (void *pvParameters)
{
    int32_t lReceivedValue;
    BaseType_t xStatus;
    const TickType_t xTicksToWait = pdMS_TO_TICKS( 100 );
    
    // implement in infinite loop
    for(;;)
    {
        // Call should find queue empty
        if (uxQueueMessagesWaiting(xQueue) != 0)
        {
            vOLEDString(0, 0, "Queue should be empty"); 
            
        }
        
        // Receive data from queue
        // First param is data to be received
        // Second param is buffer into which received data will be placed
        // Last param is block time, max time will be in blocked state to
        // Receive data
         xStatus = xQueueReceive(xQueue, &lReceivedValue, xTicksToWait);
         
         // Data receive successful
         if (xStatus == pdPASS)
         {
             vOLEDInteger(0, 0, lReceivedValue);
         }
         else
         {
             // Error data not received
             vOLEDString(0, 0, "Error Receive");
         }
    }
}


/*******************************************************************************
 * Function:        void prvSetupHardware(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Overview:        Sets up hardware that is to be used by RTOS
 * 
 * Usage:           None
 *
 * Note:            None
 ******************************************************************************/
void prvSetupHardware(void)
{
    /////////////////////////
    //initialize the device
    ///////////////////////
     SYSTEM_Initialize();
     __delay_ms(1000);
    
     ///////////////////////
     // Initialize SSD1306
     //////////////////////
     SSD1306_INIT();
     __delay_ms(1000);
    
     // Write startup logo
     SSD1306_Write_Buffer();
     __delay_ms(2000);
     
     // Clear display
     SSD1306_Clear_Display();
    
     ////////////////////
     // Configure Ports
     ///////////////////
     
     // Configure LED
     TRISAbits.TRISA7 = 0;
     
     // Configure heartbeat LED for IDLE
     TRISBbits.TRISB9 = 0;
}

/*******************************************************************************
 * Function:        void vApplicationIdleHook(void)
 *
 * PreCondition:    configUSE_IDLE_HOOK in FreeTROSconfig.h must be set to 1
 *
 * Input:           None
 *
 * Output:          None
 *
 * Overview:        This task is called when the CPU has no tasks to run
 * 
 * Usage:           None
 *
 * Note:            Task MUST take no parameters and return void also must not
 *                  call blocking functions or attempt to suspend.
 ******************************************************************************/
void vApplicationIdleHook(void)
{
    // Toggle LED
    LATBbits.LATB9 = ~LATBbits.LATB9;
}

/*******************************************************************************
 * Function:        void vOLEDString(uint8_t x, uint8_t y, char* String)
 *
 * PreCondition:    None
 *
 * Input:           X and Y coordinates and string
 *
 * Output:          None
 *
 * Overview:        Prints a string for a duration of one second on OLED
 * 
 * Usage:           None
 *
 * Note:            None
 ******************************************************************************/
void vOLEDString(uint8_t x, uint8_t y, char* String)
{
     // Write Text Passed as Parameters
     SSD1306_Write_Text( x, y, String, 1, WHITE);
     // Write to OLED
     SSD1306_Write_Buffer();
     __delay_ms(1000);
     // Clear Display
     SSD1306_Clear_Display();
}

/*******************************************************************************
 * Function:        void vOLEDInteger(uint8_t x, uint8_t y, uint32_t z)
 *
 * PreCondition:    None
 *
 * Input:           X and Y coordinates and integer to write
 *
 * Output:          None
 *
 * Overview:        Prints an integer for a duration of one second on OLED
 * 
 * Usage:           None
 *
 * Note:            None
 ******************************************************************************/
void vOLEDInteger(uint8_t x, uint8_t y, uint32_t z)
{
     // Write Text Passed as Parameters
     SSD1306_Write_Integer( x, y, z, 1);
     // Write to OLED
     SSD1306_Write_Buffer();
     __delay_ms(1000);
     // Clear Display
     SSD1306_Clear_Display();
}

